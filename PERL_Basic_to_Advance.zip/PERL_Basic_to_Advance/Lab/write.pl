=begin
open (p, ">pppt.ppt");
open (d, ">", "perllllll.pl");
my $file="123.txt";
open (w, ">", 'C:\Users\Tamsila\Desktop\abc.txt');
open (a, ">>$file");
=cutopen(DATA, "<file.txt") or die "Couldn't open file file.txt, $!";print getc(DATA);
print "\n\n";