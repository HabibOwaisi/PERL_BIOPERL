%var = ("name" =>"paul", "age"=>33, "Address"=>"121B street 2");
@keys= keys %var;
$size= @keys;
print "1 - Hash size is: $size\n";
print "Name of the key name  ". $var{'name'}. "\n\n";

